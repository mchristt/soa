﻿using LearnOpenTK.Common;
using OpenTK.Windowing.Desktop;
using OpenTK.Mathematics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using OpenTK.Graphics.OpenGL4;

namespace UAS_GrafKom
{
    class Mesh
    {
        List<Vector3> vertices = new List<Vector3>();
        List<Vector3> textureVertices = new List<Vector3>();
        List<Vector3> normals = new List<Vector3>();
        List<uint> vertexIndices = new List<uint>();
        int _vertexBufferObject;
        int _elementBufferObject;
        int _vertexArrayObject;
        int _normals;
        Matrix4 transform;
        Vector3 _position;
        Vector3 _rotation;


        public List<Mesh> child = new List<Mesh>();
        public Mesh()
        {
        }
        public void setupObject(float Sizex, float Sizey, Shader _lightingShader, float PosX, float PosY, float PosZ, float RotX, float RotY, float RotZ)
        {
            //Transformasi
            transform = Matrix4.Identity;

            //Simpan posisi & rotasi awal
            _position = new Vector3(PosX, PosY, PosZ);
            _rotation = new Vector3(RotX, RotY, RotZ);

            //VBO
            _vertexBufferObject = GL.GenBuffer();
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, vertices.Count * Vector3.SizeInBytes, vertices.ToArray(), BufferUsageHint.StaticDraw);

            ////Attempt untuk Normals nya (VBO / Load data ke int _normals)------------------------------------------------
            //_normals = GL.GenBuffer();
            //GL.BindBuffer(BufferTarget.ArrayBuffer, _normals);
            //GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, normals.Count * Vector3.SizeInBytes, vertices.ToArray(), BufferUsageHint.StaticDraw);
            ////------------------------------------------------------------------------------------------------------

            //VAO
            _vertexArrayObject = GL.GenVertexArray();
            GL.BindVertexArray(_vertexArrayObject);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);
            GL.EnableVertexAttribArray(0);
            var vertexLocation = _lightingShader.GetAttribLocation("aPosition");
            GL.EnableVertexAttribArray(vertexLocation);
            GL.VertexAttribPointer(vertexLocation, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);

            //[Di-comment dulu ]
            var normalLocation = _lightingShader.GetAttribLocation("aNormal");
            GL.EnableVertexAttribArray(normalLocation);
            GL.VertexAttribPointer(normalLocation, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0 * sizeof(float));

            ////Attempt untuk Normals nya (VAO dari int _normals)------------------------------------------------
            //var normalLocation = _normals;
            //GL.EnableVertexAttribArray(normalLocation);
            //GL.VertexAttribPointer(normalLocation, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0 * sizeof(float));
            ////--------------------------------------------------------------------------------------------------

            //Index vertex
            _elementBufferObject = GL.GenBuffer();
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject);
            GL.BufferData(BufferTarget.ElementArrayBuffer, vertexIndices.Count * sizeof(uint), vertexIndices.ToArray(), BufferUsageHint.StaticDraw);


            //Posisi & Rotasi awal
            transform = transform * Matrix4.CreateRotationX(MathHelper.DegreesToRadians(_rotation.X));
            transform = transform * Matrix4.CreateRotationY(MathHelper.DegreesToRadians(_rotation.Y));
            transform = transform * Matrix4.CreateRotationZ(MathHelper.DegreesToRadians(_rotation.Z));
            transform = transform * Matrix4.CreateTranslation(_position);
        }
        public void render(Camera _camera, Vector3 _lightPos, Shader _lightingShader, Vector3 _lightColor, Vector3 _objectcolor)
        {
            GL.BindVertexArray(_vertexArrayObject);
            //_lightingShader.Use();
            _lightingShader.SetMatrix4("transform", transform);
            _lightingShader.SetMatrix4("view", _camera.GetViewMatrix());
            _lightingShader.SetMatrix4("projection", _camera.GetProjectionMatrix());
            _lightingShader.SetVector3("objectColor", _objectcolor);
            _lightingShader.SetVector3("lightColor", _lightColor);
            _lightingShader.SetVector3("lightPos", _lightPos);
            _lightingShader.SetVector3("viewPos", _camera.Position);
            GL.DrawElements(PrimitiveType.Triangles, vertexIndices.Count, DrawElementsType.UnsignedInt, 0);
        }
        public List<Vector3> getVertices()
        {
            return vertices;
        }
        public List<uint> getVertexIndices()
        {
            return vertexIndices;
        }
        public void setVertexIndices(List<uint> temp)
        {
            vertexIndices = temp;
        }
        public int getVertexBufferObject()
        {
            return _vertexBufferObject;
        }
        public int getElementBufferObject()
        {
            return _elementBufferObject;
        }
        public int getVertexArrayObject()
        {
            return _vertexArrayObject;
        }
        public Matrix4 getTransform()
        {
            return transform;
        }
        public void rotate(Shader _lightingShader, Camera _camera, float RotX, float RotY, float RotZ)
        {
            transform = transform * Matrix4.CreateRotationX(MathHelper.DegreesToRadians(RotX));
            transform = transform * Matrix4.CreateRotationY(MathHelper.DegreesToRadians(RotY));
            transform = transform * Matrix4.CreateRotationZ(MathHelper.DegreesToRadians(RotZ));
        }
        public void scale(Shader _lightingShader, Camera _camera, float value)
        {
            transform = transform * Matrix4.CreateScale(value);
        }
        public void translate(Shader _lightingShader, Camera _camera, float X, float Y, float Z)
        {
            transform = transform * Matrix4.CreateTranslation(_position);
        }
        public void LoadObjFile(string path)
        {
            if (!File.Exists(path))
            {
                throw new FileNotFoundException("Unable to open \"" + path + "\", does not exist.");
            }
            using (StreamReader streamReader = new StreamReader(path))
            {
                while (!streamReader.EndOfStream)
                {
                    List<string> words = new List<string>(streamReader.ReadLine().ToLower().Split(' '));
                    words.RemoveAll(s => s == string.Empty);
                    if (words.Count == 0)
                        continue;

                    string type = words[0];
                    words.RemoveAt(0);

                    switch (type)
                    {
                        case "v":
                            vertices.Add(new Vector3(float.Parse(words[0]), float.Parse(words[1]), float.Parse(words[2])));
                            break;
                        case "vt":
                            textureVertices.Add(new Vector3(float.Parse(words[0]), float.Parse(words[1]),
                                                            words.Count < 3 ? 0 : float.Parse(words[2])));
                            break;
                        case "vn":
                            normals.Add(new Vector3(float.Parse(words[0]), float.Parse(words[1]), float.Parse(words[2])));
                            break;
                        case "f":
                            foreach (string w in words)
                            {
                                if (w.Length == 0)
                                    continue;
                                string[] comps = w.Split('/');
                                vertexIndices.Add(uint.Parse(comps[0]) - 1);
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        public void createBoxVertices(float x, float y, float z)
        {
            //biar lebih fleksibel jangan inisialiasi posisi dan 
            //panjang kotak didalam tapi ditaruh ke parameter
            float _positionX = x;
            float _positionY = y;
            float _positionZ = z;

            float _boxLength = 0.5f;

            //Buat temporary vector
            Vector3 temp_vector;
            //1. Inisialisasi vertex
            // Titik 1
            temp_vector.X = _positionX - _boxLength / 2.0f; // x 
            temp_vector.Y = _positionY + _boxLength / 2.0f; // y
            temp_vector.Z = _positionZ - _boxLength / 2.0f; // z

            vertices.Add(temp_vector);

            // Titik 2
            temp_vector.X = _positionX + _boxLength / 2.0f; // x
            temp_vector.Y = _positionY + _boxLength / 2.0f; // y
            temp_vector.Z = _positionZ - _boxLength / 2.0f; // z

            vertices.Add(temp_vector);
            // Titik 3
            temp_vector.X = _positionX - _boxLength / 2.0f; // x
            temp_vector.Y = _positionY - _boxLength / 2.0f; // y
            temp_vector.Z = _positionZ - _boxLength / 2.0f; // z
            vertices.Add(temp_vector);

            // Titik 4
            temp_vector.X = _positionX + _boxLength / 2.0f; // x
            temp_vector.Y = _positionY - _boxLength / 2.0f; // y
            temp_vector.Z = _positionZ - _boxLength / 2.0f; // z

            vertices.Add(temp_vector);

            // Titik 5
            temp_vector.X = _positionX - _boxLength / 2.0f; // x
            temp_vector.Y = _positionY + _boxLength / 2.0f; // y
            temp_vector.Z = _positionZ + _boxLength / 2.0f; // z

            vertices.Add(temp_vector);

            // Titik 6
            temp_vector.X = _positionX + _boxLength / 2.0f; // x
            temp_vector.Y = _positionY + _boxLength / 2.0f; // y
            temp_vector.Z = _positionZ + _boxLength / 2.0f; // z

            vertices.Add(temp_vector);

            // Titik 7
            temp_vector.X = _positionX - _boxLength / 2.0f; // x
            temp_vector.Y = _positionY - _boxLength / 2.0f; // y
            temp_vector.Z = _positionZ + _boxLength / 2.0f; // z

            vertices.Add(temp_vector);

            // Titik 8
            temp_vector.X = _positionX + _boxLength / 2.0f; // x
            temp_vector.Y = _positionY - _boxLength / 2.0f; // y
            temp_vector.Z = _positionZ + _boxLength / 2.0f; // z

            vertices.Add(temp_vector);
            //2. Inisialisasi index vertex
            //Ada yang di-komen karena cuma untuk buat tanah/plane
            vertexIndices = new List<uint> {
                // Segitiga Depan 1
                //0, 1, 2,
                // Segitiga Depan 2
                //1, 2, 3,
                // Segitiga Atas 1
                0, 4, 5,
                // Segitiga Atas 2
                0, 1, 5,
                // Segitiga Kanan 1
                //1, 3, 5,
                // Segitiga Kanan 2
                //3, 5, 7,
                // Segitiga Kiri 1
                //0, 2, 4,
                // Segitiga Kiri 2
                //2, 4, 6,
                // Segitiga Belakang 1
                //4, 5, 6,
                // Segitiga Belakang 2
                //5, 6, 7,
                // Segitiga Bawah 1
                //2, 3, 6,
                // Segitiga Bawah 2
                //3, 6, 7
            };
        }
    }
}
