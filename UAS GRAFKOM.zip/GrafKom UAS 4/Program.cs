﻿using System;
using OpenTK.Windowing.Desktop;
using OpenTK.Mathematics;

namespace UAS_GrafKom
{
    class Program
    {
        static void Main(string[] args)
        {
            var ourWindow = new NativeWindowSettings()
            {
                Size = new Vector2i(800, 800),
                Title = "UAS GRAFKOM"
            };
            using (var win = new UAS_GrafKom.window(GameWindowSettings.Default, ourWindow))
            {
                win.Run();
            }
        }
    }

}
